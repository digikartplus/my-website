
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, Clock, Shield, Wrench, ArrowRight } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';

const HomePage = () => {
  const benefits = [
    {
      icon: Clock,
      title: 'Same-day service',
      description: 'Fast response times with most repairs completed within 24 hours of your call'
    },
    {
      icon: Shield,
      title: 'Licensed technicians',
      description: 'All our technicians are certified professionals with years of experience'
    },
    {
      icon: CheckCircle,
      title: 'Quality guarantee',
      description: 'We stand behind our work with a comprehensive warranty on all repairs'
    }
  ];

  const featuredServices = [
    'Washing machine repair',
    'Refrigerator service',
    'AC maintenance',
    'Microwave repair'
  ];

  return (
    <>
      <Helmet>
        <title>GDS SMART SERVICE - Professional home appliance repair</title>
        <meta name="description" content="Fast, reliable home appliance repair services. Same-day service available for washing machines, refrigerators, AC units, and more." />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1">
          <section className="relative min-h-[100dvh] flex items-center overflow-hidden">
            <div 
              className="absolute inset-0 z-0"
              style={{
                backgroundImage: 'url(https://images.unsplash.com/photo-1699457062599-da2e073c78ee)',
                backgroundSize: 'cover',
                backgroundPosition: 'center'
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/85 to-background/70" />
            </div>

            <div className="container relative z-10 py-20">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="max-w-2xl"
              >
                <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6" style={{letterSpacing: '-0.02em'}}>
                  GDS SMART SERVICE
                </h1>
                <p className="text-xl md:text-2xl text-muted-foreground mb-8 leading-relaxed">
                  Professional home appliance repair and maintenance. Fast, reliable service you can trust.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button asChild size="lg" className="text-base">
                    <Link to="/booking">
                      Book a service
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Link>
                  </Button>
                  <Button asChild variant="outline" size="lg" className="text-base">
                    <Link to="/services">View all services</Link>
                  </Button>
                </div>
              </motion.div>
            </div>
          </section>

          <section className="py-20 bg-muted">
            <div className="container">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="text-center mb-12"
              >
                <h2 className="text-3xl md:text-4xl font-semibold text-foreground mb-4">
                  Why choose us
                </h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  We deliver exceptional service with a commitment to quality and customer satisfaction
                </p>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {benefits.map((benefit, index) => (
                  <motion.div
                    key={benefit.title}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="bg-card rounded-2xl p-8 border border-border"
                  >
                    <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-6">
                      <benefit.icon className="w-7 h-7 text-primary" />
                    </div>
                    <h3 className="text-xl font-semibold text-foreground mb-3">
                      {benefit.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {benefit.description}
                    </p>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          <section className="py-20">
            <div className="container">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5 }}
                >
                  <h2 className="text-3xl md:text-4xl font-semibold text-foreground mb-6">
                    Expert repair for all major appliances
                  </h2>
                  <p className="text-lg text-muted-foreground leading-relaxed mb-6">
                    Our certified technicians handle repairs for all major home appliances. From washing machines to refrigerators, we have the expertise to get your appliances running smoothly again.
                  </p>
                  <ul className="space-y-3 mb-8">
                    {featuredServices.map((service) => (
                      <li key={service} className="flex items-center gap-3">
                        <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                        <span className="text-foreground">{service}</span>
                      </li>
                    ))}
                  </ul>
                  <Button asChild size="lg">
                    <Link to="/services">
                      View all services
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Link>
                  </Button>
                </motion.div>

                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5 }}
                  className="relative"
                >
                  <div className="aspect-square rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                    <Wrench className="w-32 h-32 text-primary/40" />
                  </div>
                </motion.div>
              </div>
            </div>
          </section>

          <section className="py-20 bg-primary text-primary-foreground">
            <div className="container">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
                className="text-center max-w-3xl mx-auto"
              >
                <h2 className="text-3xl md:text-4xl font-semibold mb-6">
                  Ready to fix your appliance?
                </h2>
                <p className="text-lg text-primary-foreground/90 mb-8 leading-relaxed">
                  Book your service appointment today and get your appliances back to working order. Our team is ready to help.
                </p>
                <Button asChild size="lg" variant="secondary">
                  <Link to="/booking">
                    Schedule a repair
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Link>
                </Button>
              </motion.div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default HomePage;
