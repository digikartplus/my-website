
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import pb from '@/lib/pocketbaseClient';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import TimeSlotSelector from '@/components/TimeSlotSelector.jsx';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Loader2 } from 'lucide-react';

const BookingPage = () => {
  const navigate = useNavigate();
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    service: '',
    booking_date: '',
    booking_time: '',
    customer_name: '',
    phone_number: '',
    address: ''
  });

  useEffect(() => {
    const fetchServices = async () => {
      try {
        const records = await pb.collection('services').getFullList({
          sort: 'name',
          $autoCancel: false
        });
        setServices(records);
      } catch (error) {
        console.error('Error fetching services:', error);
        toast.error('Failed to load services');
      }
    };

    fetchServices();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleServiceChange = (value) => {
    setFormData(prev => ({ ...prev, service: value }));
  };

  const handleTimeSlotChange = (value) => {
    setFormData(prev => ({ ...prev, booking_time: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.service || !formData.booking_date || !formData.booking_time || 
        !formData.customer_name || !formData.phone_number || !formData.address) {
      toast.error('Please fill in all fields');
      return;
    }

    setLoading(true);

    try {
      const bookingData = {
        ...formData,
        booking_status: 'pending'
      };

      const record = await pb.collection('bookings').create(bookingData, { $autoCancel: false });
      
      toast.success('Booking created successfully');
      navigate(`/confirmation/${record.id}`, { state: { booking: record } });
    } catch (error) {
      console.error('Error creating booking:', error);
      toast.error('Failed to create booking. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Book a service - GDS SMART SERVICE</title>
        <meta name="description" content="Schedule your appliance repair service. Choose your preferred date and time, and our technicians will be there to help." />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1 py-20">
          <div className="container max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4" style={{letterSpacing: '-0.02em'}}>
                Book a service
              </h1>
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                Fill out the form below to schedule your appliance repair. We'll confirm your appointment shortly.
              </p>

              <form onSubmit={handleSubmit} className="bg-card rounded-2xl p-8 border border-border space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="service">Service type</Label>
                  <Select value={formData.service} onValueChange={handleServiceChange}>
                    <SelectTrigger id="service" className="text-foreground">
                      <SelectValue placeholder="Select a service" />
                    </SelectTrigger>
                    <SelectContent>
                      {services.map((service) => (
                        <SelectItem key={service.id} value={service.name}>
                          {service.name} - ${service.price}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="booking_date">Preferred date</Label>
                  <Input
                    type="date"
                    id="booking_date"
                    name="booking_date"
                    value={formData.booking_date}
                    onChange={handleInputChange}
                    min={new Date().toISOString().split('T')[0]}
                    required
                    className="text-foreground"
                  />
                </div>

                <TimeSlotSelector
                  selectedSlot={formData.booking_time}
                  onSlotChange={handleTimeSlotChange}
                />

                <div className="space-y-2">
                  <Label htmlFor="customer_name">Full name</Label>
                  <Input
                    type="text"
                    id="customer_name"
                    name="customer_name"
                    value={formData.customer_name}
                    onChange={handleInputChange}
                    placeholder="Enter your full name"
                    required
                    className="text-foreground placeholder:text-muted-foreground"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone_number">Phone number</Label>
                  <Input
                    type="tel"
                    id="phone_number"
                    name="phone_number"
                    value={formData.phone_number}
                    onChange={handleInputChange}
                    placeholder="+1 (555) 123-4567"
                    required
                    className="text-foreground placeholder:text-muted-foreground"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Service address</Label>
                  <Textarea
                    id="address"
                    name="address"
                    value={formData.address}
                    onChange={handleInputChange}
                    placeholder="Enter your complete address"
                    rows={3}
                    required
                    className="text-foreground placeholder:text-muted-foreground"
                  />
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="w-full"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Creating booking...
                    </>
                  ) : (
                    'Confirm booking'
                  )}
                </Button>
              </form>
            </motion.div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default BookingPage;
