
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useParams, useLocation, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import pb from '@/lib/pocketbaseClient';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';
import { CheckCircle, Calendar, Clock, User, Phone, MapPin, Wrench } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

const ConfirmationPage = () => {
  const { id } = useParams();
  const location = useLocation();
  const [booking, setBooking] = useState(location.state?.booking || null);
  const [loading, setLoading] = useState(!booking);

  useEffect(() => {
    if (!booking) {
      const fetchBooking = async () => {
        try {
          const record = await pb.collection('bookings').getOne(id, { $autoCancel: false });
          setBooking(record);
        } catch (error) {
          console.error('Error fetching booking:', error);
        } finally {
          setLoading(false);
        }
      };

      fetchBooking();
    }
  }, [id, booking]);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  const formatTimeSlot = (slot) => {
    const slots = {
      morning: 'Morning (8:00 AM - 12:00 PM)',
      afternoon: 'Afternoon (12:00 PM - 5:00 PM)',
      evening: 'Evening (5:00 PM - 9:00 PM)'
    };
    return slots[slot] || slot;
  };

  if (loading) {
    return (
      <>
        <Helmet>
          <title>Booking confirmation - GDS SMART SERVICE</title>
        </Helmet>
        <div className="min-h-screen flex flex-col">
          <Header />
          <main className="flex-1 py-20">
            <div className="container max-w-3xl">
              <div className="bg-card rounded-2xl p-8 border border-border">
                <Skeleton className="h-12 w-12 rounded-full mb-6" />
                <Skeleton className="h-10 w-3/4 mb-4" />
                <Skeleton className="h-6 w-full mb-8" />
                <div className="space-y-4">
                  {[1, 2, 3, 4, 5].map((i) => (
                    <Skeleton key={i} className="h-16 w-full" />
                  ))}
                </div>
              </div>
            </div>
          </main>
          <Footer />
        </div>
      </>
    );
  }

  if (!booking) {
    return (
      <>
        <Helmet>
          <title>Booking not found - GDS SMART SERVICE</title>
        </Helmet>
        <div className="min-h-screen flex flex-col">
          <Header />
          <main className="flex-1 py-20">
            <div className="container max-w-3xl text-center">
              <h1 className="text-3xl font-bold text-foreground mb-4">Booking not found</h1>
              <p className="text-muted-foreground mb-8">We couldn't find the booking you're looking for.</p>
              <Button asChild>
                <Link to="/">Back to home</Link>
              </Button>
            </div>
          </main>
          <Footer />
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>{`Booking confirmation - ${booking.id} - GDS SMART SERVICE`}</title>
        <meta name="description" content="Your appliance repair service has been successfully booked. We'll contact you shortly to confirm your appointment." />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1 py-20">
          <div className="container max-w-3xl">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="bg-card rounded-2xl p-8 border border-border"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                  <CheckCircle className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <h1 className="text-3xl font-bold text-foreground">Booking confirmed</h1>
                  <p className="text-muted-foreground">Booking ID: {booking.id}</p>
                </div>
              </div>

              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                Thank you for choosing GDS SMART SERVICE. We've received your booking and will contact you shortly to confirm your appointment.
              </p>

              <div className="space-y-4">
                <div className="flex items-start gap-4 p-4 rounded-xl bg-muted">
                  <Wrench className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-muted-foreground mb-1">Service</p>
                    <p className="text-foreground font-semibold">{booking.service}</p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 rounded-xl bg-muted">
                  <Calendar className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-muted-foreground mb-1">Date</p>
                    <p className="text-foreground font-semibold">{formatDate(booking.booking_date)}</p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 rounded-xl bg-muted">
                  <Clock className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-muted-foreground mb-1">Time slot</p>
                    <p className="text-foreground font-semibold">{formatTimeSlot(booking.booking_time)}</p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 rounded-xl bg-muted">
                  <User className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-muted-foreground mb-1">Customer name</p>
                    <p className="text-foreground font-semibold">{booking.customer_name}</p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 rounded-xl bg-muted">
                  <Phone className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-muted-foreground mb-1">Phone number</p>
                    <p className="text-foreground font-semibold">{booking.phone_number}</p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 rounded-xl bg-muted">
                  <MapPin className="w-6 h-6 text-primary mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-muted-foreground mb-1">Service address</p>
                    <p className="text-foreground font-semibold">{booking.address}</p>
                  </div>
                </div>
              </div>

              <div className="mt-8 pt-8 border-t border-border">
                <Button asChild size="lg" className="w-full">
                  <Link to="/">Back to home</Link>
                </Button>
              </div>
            </motion.div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default ConfirmationPage;
