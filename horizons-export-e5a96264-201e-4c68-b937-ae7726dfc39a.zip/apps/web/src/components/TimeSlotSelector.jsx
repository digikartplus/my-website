
import React from 'react';
import { Clock } from 'lucide-react';

const TimeSlotSelector = ({ selectedSlot, onSlotChange }) => {
  const timeSlots = [
    { value: 'morning', label: 'Morning', time: '8:00 AM - 12:00 PM' },
    { value: 'afternoon', label: 'Afternoon', time: '12:00 PM - 5:00 PM' },
    { value: 'evening', label: 'Evening', time: '5:00 PM - 9:00 PM' }
  ];

  return (
    <div className="space-y-3">
      <label className="text-sm font-medium text-foreground">
        Preferred time slot
      </label>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {timeSlots.map((slot) => (
          <button
            key={slot.value}
            type="button"
            onClick={() => onSlotChange(slot.value)}
            className={`
              relative p-4 rounded-xl border-2 transition-all duration-200
              ${selectedSlot === slot.value
                ? 'border-primary bg-primary/5 shadow-md'
                : 'border-border bg-card hover:border-primary/50 hover:bg-muted'
              }
            `}
          >
            <div className="flex items-start gap-3">
              <Clock className={`w-5 h-5 mt-0.5 ${selectedSlot === slot.value ? 'text-primary' : 'text-muted-foreground'}`} />
              <div className="text-left">
                <div className={`font-semibold ${selectedSlot === slot.value ? 'text-primary' : 'text-foreground'}`}>
                  {slot.label}
                </div>
                <div className="text-sm text-muted-foreground mt-0.5">
                  {slot.time}
                </div>
              </div>
            </div>
            {selectedSlot === slot.value && (
              <div className="absolute top-2 right-2 w-2 h-2 bg-primary rounded-full" />
            )}
          </button>
        ))}
      </div>
    </div>
  );
};

export default TimeSlotSelector;
