
import React from 'react';
import { Phone, Mail, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-secondary text-secondary-foreground mt-20">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">GDS SMART SERVICE</h3>
            <p className="text-secondary-foreground/80 leading-relaxed">
              Professional home appliance repair and maintenance services. Fast, reliable, and affordable solutions for all your appliance needs.
            </p>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Quick links</h3>
            <nav className="space-y-2">
              <Link to="/" className="block text-secondary-foreground/80 hover:text-secondary-foreground transition-colors duration-200">
                Home
              </Link>
              <Link to="/services" className="block text-secondary-foreground/80 hover:text-secondary-foreground transition-colors duration-200">
                Services
              </Link>
              <Link to="/booking" className="block text-secondary-foreground/80 hover:text-secondary-foreground transition-colors duration-200">
                Book now
              </Link>
            </nav>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Contact us</h3>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-secondary-foreground/80 mt-0.5 flex-shrink-0" />
                <span className="text-secondary-foreground/80">+1 (555) 123-4567</span>
              </div>
              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-secondary-foreground/80 mt-0.5 flex-shrink-0" />
                <span className="text-secondary-foreground/80">info@gdssmartservice.com</span>
              </div>
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-secondary-foreground/80 mt-0.5 flex-shrink-0" />
                <span className="text-secondary-foreground/80">123 Service Street, Tech City, TC 12345</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-border/50 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-secondary-foreground/70">
            © 2026 GDS SMART SERVICE. All rights reserved.
          </p>
          <div className="flex gap-6">
            <Link to="#" className="text-sm text-secondary-foreground/70 hover:text-secondary-foreground transition-colors duration-200">
              Privacy Policy
            </Link>
            <Link to="#" className="text-sm text-secondary-foreground/70 hover:text-secondary-foreground transition-colors duration-200">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
