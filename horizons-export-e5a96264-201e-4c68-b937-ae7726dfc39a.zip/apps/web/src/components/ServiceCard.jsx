
import React from 'react';
import { Wrench } from 'lucide-react';

const ServiceCard = ({ service }) => {
  return (
    <div className="bg-card rounded-2xl p-6 border border-border hover:shadow-lg transition-all duration-300 hover:-translate-y-1 flex flex-col h-full">
      <div className="flex items-start gap-4 mb-4">
        <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
          <Wrench className="w-6 h-6 text-primary" />
        </div>
        <div className="flex-1">
          <h3 className="text-xl font-semibold text-foreground mb-1">
            {service.name}
          </h3>
          {service.category && (
            <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
              {service.category}
            </span>
          )}
        </div>
      </div>
      
      {service.description && (
        <p className="text-muted-foreground leading-relaxed mb-4 flex-1">
          {service.description}
        </p>
      )}
      
      <div className="mt-auto pt-4 border-t border-border">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-muted-foreground">Starting at</span>
          <span className="text-2xl font-bold text-primary" style={{fontVariantNumeric: 'tabular-nums'}}>
            ${service.price}
          </span>
        </div>
      </div>
    </div>
  );
};

export default ServiceCard;
